import sys
import telepot
from telepot.loop import MessageLoop
import time
from time import sleep
from datetime import datetime
from pprint import pprint
from gpiozero import Button
from gpiozero import Buzzer
from gpiozero import OutputDevice

timestamp = datetime.now().strftime('Data: %d-%m-%Y\nChas: %H:%M:%S')

timestampDate = datetime.now().strftime('%d-%m-%Y')
timestampTime = datetime.now().strftime('%H:%M')

REED_PIN = 18
BZ_PIN = 17
RELAY_PIN = 12

TOKEN = ''
myId = 

reed = Button(REED_PIN)
bz = Buzzer(BZ_PIN)
relay = OutputDevice(RELAY_PIN, active_high=False, initial_value=False)

global prevState
prevState = 'null'

def checkId(chat_id):
    if chat_id == myId:
        return True
    else:
        return False

def alarm():
    bz.beep(on_time=0.1,off_time=0.2,n=2)

def snitchMsg(message):
    bot = telepot.Bot(TOKEN)
    bot.sendMessage(myId, message)

def snitchHTMLMsg(message):
    bot = telepot.Bot(TOKEN)
    bot.sendMessage(myId, message, parse_mode=Html)

def sendMsg(id, message, parsemode):
    bot = telepot.Bot(TOKEN)
    bot.sendMessage(id, message, parse_mode=parsemode)

def handle(msg):
    chat_id = msg['chat']['id']
#    statuus = ' '
    if checkId(chat_id) == True:
        entities_type = ' '
        if 'entities' in msg:
            entities_type = msg['entities'][0]['type']
            if entities_type == 'bot_command':
                command = msg['text']
                if command == '/ron':
                    message = "Toggling relay on . . . "
                    snitchMsg(message)
                    relay.toggle()
                elif command == '/roff':
                    message = 'Toggling relay off . . . '
                    snitchMsg(message)
                    relay.toggle()
                elif command == '/status':
                    datestamp = datetime.now().strftime('%d-%m-%Y')
                    clockstamp = datetime.now().strftime('%H:%M')

                    message = '<b>Data until {} at {} o\'clock</b>\n<code>Reed status: {}</code>\n<code>Buzzer status: {}</code>\n<code>Relay status: {}</code>'.format(datestamp,clockstamp, reed.is_active, bz.is_active, relay.is_active)
#                    sendHTMLMsg(message)
                    bot.sendMessage(myId, message, parse_mode='Html')
        else:
            entities_type = ' '
    else:
        id = msg['chat']['id']
        text = msg['text']
        message = '<b>He said: {}</b>'.format(text)
        parsemode = 'Html'
        sendMsg(id, message, parsemode)

bot = telepot.Bot(TOKEN)
MessageLoop(bot, handle).run_as_thread()
print('\nUp and Running . . . ')

def main_loop():
    relay.off()
    while True:
        currState = reed.is_active
        global prevState
        if currState == False and prevState == "closed" or currState == False and prevState == "null":
            prevState = "opened"
            message = ("VRATATA E OTVORENA\n" + timestamp)
            snitchMsg(message)
            alarm()
        if currState != False and prevState == "opened" or currState != False and prevState == "null":
            prevState = "closed"
            message = ("VRATATA E ZATVORENA\n" + timestamp)
            snitchMsg(message)
            bz.off()

        time.sleep(1)
try:
    main_loop()
except KeyboardInterrupt:
    print('\nExiting app\n')
    relay.off()
    sys.exit(0)
