import serial
from gpiozero import PWMLED

ser = serial.Serial('/dev/ttyACM0', 9600)
pwmled = PWMLED(16)

while True:
    valuepot = float(ser.readline().strip())
    print ('New val is {0:0.2f}'.format(valuepot))
    pwmled.value=valuepot
